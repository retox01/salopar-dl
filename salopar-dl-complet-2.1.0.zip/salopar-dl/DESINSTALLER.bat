@echo off
title Salopar DL - desinstallation
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\desinstaller.ps1"
