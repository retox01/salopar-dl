@echo off
title Salopar DL - installation
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\installer.ps1"
