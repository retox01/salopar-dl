﻿# Salopar DL - désinstallation (les fichiers téléchargés ne sont PAS supprimés)
$ErrorActionPreference = 'Continue'
$App = Join-Path $env:LOCALAPPDATA 'SaloparDL'
$Hote = 'com.salopar.dl'
Write-Host ''
Write-Host '  Désinstallation de Salopar DL...' -ForegroundColor Magenta
foreach ($k in @('HKCU:\Software\Google\Chrome\NativeMessagingHosts', 'HKCU:\Software\Microsoft\Edge\NativeMessagingHosts',
                 'HKCU:\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts', 'HKCU:\Software\Chromium\NativeMessagingHosts',
                 'HKCU:\Software\Vivaldi\NativeMessagingHosts', 'HKCU:\Software\Opera Software\NativeMessagingHosts')) {
    if (Test-Path "$k\$Hote") { Remove-Item "$k\$Hote" -Recurse -Force }
}
Write-Host '    [OK] Programme débranché des navigateurs' -ForegroundColor Green
if (Test-Path $App) {
    Get-Process python*, pythonw* -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "$App*" } | Stop-Process -Force -ErrorAction SilentlyContinue
    Remove-Item $App -Recurse -Force
    Write-Host "    [OK] Dossier supprimé : $App" -ForegroundColor Green
}
Write-Host ''
Write-Host '  Dernière étape : dans chrome://extensions, clique « Supprimer » sur Salopar DL.' -ForegroundColor White
Write-Host '  Tes vidéos et MP3 restent dans Téléchargements\Salopar DL.' -ForegroundColor Gray
Write-Host ''
Read-Host '  Appuie sur Entrée pour fermer' | Out-Null
