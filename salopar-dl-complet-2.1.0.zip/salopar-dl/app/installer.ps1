﻿# Salopar DL - installation (aucun droit administrateur nécessaire)
# Installe : Python (si besoin), yt-dlp, ffmpeg, Deno, puis branche le programme sur Chrome / Edge / Brave.
# NB : 'Continue' exprès. Avec 'Stop', Windows PowerShell 5.1 considère le moindre avertissement de pip comme une erreur fatale.
$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

$Ici = Split-Path -Parent $MyInvocation.MyCommand.Definition
$Racine = Split-Path -Parent $Ici
$App = Join-Path $env:LOCALAPPDATA 'SaloparDL'
$ExtId = 'keeapngdianblepopjddlklbjjodlklb'
$Hote = 'com.salopar.dl'

function Titre($t) { Write-Host ''; Write-Host "  $t" -ForegroundColor Magenta }
function Ok($t) { Write-Host "    [OK] $t" -ForegroundColor Green }
function Info($t) { Write-Host "    ...  $t" -ForegroundColor Gray }
function Ko($t) { Write-Host "    [X]  $t" -ForegroundColor Red }
function Fin($code) { Write-Host ''; Read-Host '  Appuie sur Entrée pour fermer' | Out-Null; exit $code }
function Telecharger($url, $dest) {
    Info "Téléchargement : $url"
    Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing -ErrorAction Stop
}

Clear-Host
Write-Host ''
Write-Host '   ____        _                          ____  _     ' -ForegroundColor Magenta
Write-Host '  / ___|  __ _| | ___  _ __   __ _ _ __  |  _ \| |    ' -ForegroundColor Magenta
Write-Host '  \___ \ / _` | |/ _ \| ''_ \ / _` | ''__| | | | | |    ' -ForegroundColor Magenta
Write-Host '   ___) | (_| | | (_) | |_) | (_| | |    | |_| | |___ ' -ForegroundColor Magenta
Write-Host '  |____/ \__,_|_|\___/| .__/ \__,_|_|    |____/|_____|' -ForegroundColor Magenta
Write-Host '                      |_|   YouTube & TikTok -> MP4 / MP3' -ForegroundColor DarkMagenta
Write-Host ''
Write-Host '  Installation en cours, ne ferme pas cette fenêtre (1 à 3 minutes).' -ForegroundColor White

try {
    New-Item -ItemType Directory -Force -Path $App -ErrorAction Stop | Out-Null

    # ── 1. Python ────────────────────────────────────────────────────────────
    Titre '1/5  Python'
    function Trouver-Python {
        $candidats = New-Object System.Collections.ArrayList
        if (Get-Command py -ErrorAction SilentlyContinue) { [void]$candidats.Add(@('py', '-3')) }
        foreach ($n in @('python', 'python3')) {
            $c = Get-Command $n -ErrorAction SilentlyContinue
            if ($c -and $c.Source -notlike '*WindowsApps*') { [void]$candidats.Add(@($c.Source)) }
        }
        foreach ($motif in @("$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe", "$env:ProgramFiles\Python3*\python.exe", "C:\Python3*\python.exe")) {
            Get-ChildItem $motif -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | ForEach-Object { [void]$candidats.Add(@($_.FullName)) }
        }
        foreach ($cand in $candidats) {
            try {
                $exe = $cand[0]
                $plus = @()
                if ($cand.Count -gt 1) { $plus = $cand[1..($cand.Count - 1)] }
                $sortie = & $exe @plus -c 'import sys; print(sys.executable); print(int(sys.version_info >= (3, 9)))' 2>$null
                if ($LASTEXITCODE -eq 0 -and $sortie -and $sortie.Count -ge 2 -and "$($sortie[1])".Trim() -eq '1') { return "$($sortie[0])".Trim() }
            } catch {}
        }
        return $null
    }
    $Py = Trouver-Python
    if (-not $Py) {
        if (Get-Command winget -ErrorAction SilentlyContinue) {
            Info 'Python absent : installation automatique (winget)...'
            & winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements | Out-Null
            $env:Path = [Environment]::GetEnvironmentVariable('Path', 'User') + ';' + [Environment]::GetEnvironmentVariable('Path', 'Machine')
            $Py = Trouver-Python
        }
    }
    if (-not $Py) {
        Ko 'Python est introuvable. Installe-le depuis python.org (coche « Add python.exe to PATH »), puis relance INSTALLER.bat.'
        Start-Process 'https://www.python.org/downloads/windows/'
        Fin 1
    }
    Ok "Python : $Py"

    # ── 2. yt-dlp (dans un environnement à part, propre) ────────────────────
    Titre '2/5  yt-dlp (le moteur de téléchargement)'
    $VPy = Join-Path $App 'venv\Scripts\python.exe'
    if (-not (Test-Path $VPy)) {
        Info 'Création de l''environnement Python...'
        & $Py -m venv (Join-Path $App 'venv')
        if ($LASTEXITCODE -ne 0) { throw 'Impossible de créer l''environnement Python (venv).' }
    }
    & $VPy -m pip install --upgrade --disable-pip-version-check --quiet pip | Out-Null
    & $VPy -m pip install --upgrade --disable-pip-version-check --quiet 'yt-dlp[default]' cryptography
    if ($LASTEXITCODE -ne 0) { throw 'L''installation de yt-dlp a échoué (connexion internet ?).' }
    $vyt = & $VPy -c 'import yt_dlp.version as v; print(v.__version__)'
    Ok "yt-dlp $vyt"

    # ── 3. ffmpeg ────────────────────────────────────────────────────────────
    Titre '3/5  ffmpeg (MP3, fusion image + son)'
    function Trouver-FFmpeg {
        $c = Get-Command ffmpeg -ErrorAction SilentlyContinue
        if ($c) { return $c.Source }
        foreach ($p in @("$App\ffmpeg\bin\ffmpeg.exe", "$env:LOCALAPPDATA\Microsoft\WinGet\Links\ffmpeg.exe")) { if (Test-Path $p) { return $p } }
        $g = Get-ChildItem "$env:LOCALAPPDATA\Microsoft\WinGet\Packages\*FFmpeg*\*\bin\ffmpeg.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($g) { return $g.FullName }
        return $null
    }
    $ff = Trouver-FFmpeg
    if (-not $ff) {
        Info 'ffmpeg absent : téléchargement (environ 100 Mo, patience)...'
        $zip = Join-Path $env:TEMP 'salopar-ffmpeg.zip'
        $tmp = Join-Path $App 'ffmpeg-tmp'
        Telecharger 'https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip' $zip
        if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
        New-Item -ItemType Directory -Force -Path $tmp | Out-Null
        Info 'Décompression...'
        if (Get-Command tar.exe -ErrorAction SilentlyContinue) { & tar.exe -xf $zip -C $tmp }  # bien plus rapide qu'Expand-Archive
        if (-not (Get-ChildItem $tmp -Recurse -Filter ffmpeg.exe -ErrorAction SilentlyContinue)) { Expand-Archive -Path $zip -DestinationPath $tmp -Force -ErrorAction Stop }
        $exe = Get-ChildItem $tmp -Recurse -Filter ffmpeg.exe | Select-Object -First 1
        if (-not $exe) { throw 'ffmpeg.exe introuvable dans l''archive.' }
        New-Item -ItemType Directory -Force -Path "$App\ffmpeg\bin" | Out-Null
        Copy-Item (Join-Path $exe.DirectoryName '*.exe') "$App\ffmpeg\bin" -Force -ErrorAction Stop
        Remove-Item $tmp -Recurse -Force; Remove-Item $zip -Force
        $ff = "$App\ffmpeg\bin\ffmpeg.exe"
    }
    Ok "ffmpeg : $ff"

    # ── 4. Deno (YouTube en a besoin pour lire ses vidéos) ──────────────────
    Titre '4/5  Deno (nécessaire pour YouTube)'
    $js = Get-Command deno -ErrorAction SilentlyContinue
    if (-not $js) { $js = Get-Command node -ErrorAction SilentlyContinue }
    if ($js) { Ok "Déjà présent : $($js.Source)" }
    elseif (Test-Path "$App\deno.exe") { Ok "Deno : $App\deno.exe" }
    else {
        $zip = Join-Path $env:TEMP 'salopar-deno.zip'
        Telecharger 'https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip' $zip
        Expand-Archive -Path $zip -DestinationPath $App -Force -ErrorAction Stop
        Remove-Item $zip -Force
        Ok "Deno : $App\deno.exe"
    }

    # ── 5. Fichiers + branchement aux navigateurs ───────────────────────────
    Titre '5/5  Branchement avec Chrome / Edge / Brave'
    Copy-Item (Join-Path $Ici 'host.py') (Join-Path $App 'host.py') -Force -ErrorAction Stop
    if (Test-Path (Join-Path $Ici 'update.json')) { Copy-Item (Join-Path $Ici 'update.json') (Join-Path $App 'update.json') -Force }
    $sansBom = New-Object System.Text.UTF8Encoding $false
    [IO.File]::WriteAllText((Join-Path $App 'host.bat'), "@echo off`r`n`"%~dp0venv\Scripts\python.exe`" -u `"%~dp0host.py`" %*`r`n", [Text.Encoding]::ASCII)
    $manifeste = [ordered]@{ name = $Hote; description = 'Salopar DL'; path = (Join-Path $App 'host.bat'); type = 'stdio'; allowed_origins = @("chrome-extension://$ExtId/") }
    $cheminManifeste = Join-Path $App "$Hote.json"
    [IO.File]::WriteAllText($cheminManifeste, ($manifeste | ConvertTo-Json), $sansBom)
    $cles = @('HKCU:\Software\Google\Chrome\NativeMessagingHosts', 'HKCU:\Software\Microsoft\Edge\NativeMessagingHosts',
              'HKCU:\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts', 'HKCU:\Software\Chromium\NativeMessagingHosts',
              'HKCU:\Software\Vivaldi\NativeMessagingHosts', 'HKCU:\Software\Opera Software\NativeMessagingHosts')
    foreach ($k in $cles) {
        $c = "$k\$Hote"
        New-Item -Path $c -Force -ErrorAction Stop | Out-Null
        Set-ItemProperty -Path $c -Name '(default)' -Value $cheminManifeste -ErrorAction Stop
    }
    Ok 'Programme enregistré pour Chrome, Edge, Brave, Opera, Vivaldi'

    $ext = Join-Path $App 'extension'
    if (Test-Path $ext) { Remove-Item $ext -Recurse -Force }
    Copy-Item (Join-Path $Racine 'extension') $ext -Recurse -Force -ErrorAction Stop
    Ok "Extension copiée dans : $ext"

    if (Test-Path 'HKCU:\Software\Classes\ytdl') { Remove-Item 'HKCU:\Software\Classes\ytdl' -Recurse -Force; Info 'Ancien protocole ytdl:// (version Gemini) supprimé.' }

    # petit test : le programme démarre-t-il ?
    $test = & $VPy -c 'import sys; sys.path.insert(0, sys.argv[1]); import host; print(host.trouver_ffmpeg() is not None)' $App
    if ("$test".Trim() -ne 'True') { Info 'Attention : ffmpeg n''a pas été retrouvé par le programme.' }

    try { Set-Clipboard -Value $ext } catch {}
    Write-Host ''
    Write-Host '  ===========================================================' -ForegroundColor Green
    Write-Host '   INSTALLÉ ! Dernière étape (une seule fois) :' -ForegroundColor Green
    Write-Host '  ===========================================================' -ForegroundColor Green
    Write-Host '   1. Dans Chrome, ouvre  chrome://extensions  (la page va s''ouvrir)' -ForegroundColor White
    Write-Host '   2. Active « Mode développeur » (en haut à droite)' -ForegroundColor White
    Write-Host '   3. Clique « Charger l''extension non empaquetée »' -ForegroundColor White
    Write-Host '      et choisis ce dossier (déjà copié, fais Ctrl+V dans la barre d''adresse) :' -ForegroundColor White
    Write-Host "      $ext" -ForegroundColor Yellow
    Write-Host '   4. Si tu avais l''ancienne extension « YT Downloader » de Gemini, supprime-la.' -ForegroundColor White
    Write-Host '   5. Ouvre une vidéo YouTube / TikTok et clique sur l''icône Salopar DL (en haut à droite de Chrome).' -ForegroundColor White
    Start-Process explorer.exe $ext
    foreach ($nav in @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")) {
        if (Test-Path $nav) { Start-Process $nav 'chrome://extensions/'; break }
    }
    Fin 0
}
catch {
    Write-Host ''
    Ko "Erreur : $($_.Exception.Message)"
    Write-Host '    Vérifie ta connexion internet puis relance INSTALLER.bat. Si ça bloque encore, envoie une capture de cette fenêtre.' -ForegroundColor Yellow
    Fin 1
}
