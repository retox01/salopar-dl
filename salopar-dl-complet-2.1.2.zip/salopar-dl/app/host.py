#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Salopar DL — le petit programme qui fait les téléchargements pour l'extension Chrome.

Chrome le lance tout seul quand on clique sur « Télécharger » (Native Messaging) : pas de fenêtre,
pas de serveur, rien à démarrer. Il reçoit des messages JSON, télécharge avec yt-dlp et renvoie la progression.
"""
from __future__ import annotations

import base64
import glob
import hashlib
import io
import json
import os
import platform
import re
import shutil
import struct
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
import zipfile
from pathlib import Path

VERSION = "2.1.2"
WINDOWS = platform.system() == "Windows"
APP_DIR = Path(os.environ.get("SALOPARDL_DIR") or (Path(os.environ.get("LOCALAPPDATA", Path.home() / ".local" / "share")) / "SaloparDL"))
CONFIG_FICHIER = APP_DIR / "config.json"
JOURNAL = APP_DIR / "host.log"
QUALITES_VIDEO = ["best", "2160", "1440", "1080", "720", "480", "360"]
QUALITES_AUDIO = ["320", "192", "128"]

_ecriture = threading.Lock()
_jobs: dict[str, dict] = {}
_cond = threading.Condition()
_en_cours = {"n": 0}


# ── Journal (jamais sur stdout : stdout sert à parler à Chrome) ─────────────────
def journal(*a) -> None:
    try:
        APP_DIR.mkdir(parents=True, exist_ok=True)
        if JOURNAL.exists() and JOURNAL.stat().st_size > 400_000:
            JOURNAL.replace(JOURNAL.with_suffix(".old.log"))
        with open(JOURNAL, "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + " ".join(str(x) for x in a) + "\n")
    except OSError:
        pass


# ── Protocole Native Messaging : 4 octets de longueur + JSON ────────────────────
def _binaire() -> None:
    if WINDOWS:
        import msvcrt
        msvcrt.setmode(sys.stdin.fileno(), os.O_BINARY)
        msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)


def envoyer(obj: dict) -> None:
    data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
    if len(data) > 900_000:
        data = json.dumps({k: v for k, v in obj.items() if k in ("id", "ok", "erreur", "event")}).encode("utf-8")
    with _ecriture:
        try:
            sys.stdout.buffer.write(struct.pack("<I", len(data)) + data)
            sys.stdout.buffer.flush()
        except (OSError, ValueError):  # Chrome a fermé la connexion : le téléchargement continue quand même
            pass


def lire() -> dict | None:
    tete = sys.stdin.buffer.read(4)
    if len(tete) < 4:
        return None
    n = struct.unpack("<I", tete)[0]
    return json.loads(sys.stdin.buffer.read(n).decode("utf-8"))


# ── Réglages ────────────────────────────────────────────────────────────────────
def dossier_telechargements() -> Path:
    if WINDOWS:
        try:  # le vrai dossier « Téléchargements » (même s'il a été déplacé)
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders") as k:
                v = winreg.QueryValueEx(k, "{374DE290-123F-4565-9164-39C4925E467B}")[0]
                return Path(os.path.expandvars(v))
        except OSError:
            pass
    return Path.home() / "Downloads"


DEFAUTS = {"dossier": "", "qualite_video": "best", "qualite_audio": "320", "pochette": True, "auteur_dans_nom": False, "sous_dossiers": True,
           "simultanes": "2", "limite_vitesse": "0", "sous_titres": False, "sponsorblock": False, "titres_propres": True, "maj_auto": True}


def config() -> dict:
    c = dict(DEFAUTS)
    try:
        c.update(json.loads(CONFIG_FICHIER.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        pass
    if not c.get("dossier"):
        c["dossier"] = str(dossier_telechargements() / "Salopar DL")
    return c


def valider_dossier(texte: str) -> str:
    """Dossier tapé à la main : on le crée s'il n'existe pas et on vérifie qu'on peut y écrire."""
    t = os.path.expandvars(os.path.expanduser((texte or "").strip().strip('"')))
    if not t:
        raise ValueError("Écris un dossier, par exemple C:\\Users\\toi\\Videos\\Salopar DL")
    p = Path(t)
    if not p.is_absolute():
        raise ValueError("Le dossier doit être un chemin complet, par exemple C:\\Users\\toi\\Videos\\Salopar DL")
    try:
        p.mkdir(parents=True, exist_ok=True)
        test = p / ".salopar-test"
        test.write_text("ok")
        test.unlink()
    except OSError as e:
        raise ValueError(f"Impossible d'écrire dans ce dossier ({e.strerror or e}). Choisis-en un autre.")
    return str(p)


def sauver_config(maj: dict) -> dict:
    c = config()
    for k, v in (maj or {}).items():
        if k in DEFAUTS:
            if k == "qualite_video" and v not in QUALITES_VIDEO:
                continue
            if k == "qualite_audio" and v not in QUALITES_AUDIO:
                continue
            if k == "dossier":
                v = valider_dossier(str(v))
            if k == "simultanes" and str(v) not in ("1", "2", "3", "4"):
                continue
            if k == "limite_vitesse" and str(v) not in ("0", "1", "2", "5", "10", "20"):
                continue
            c[k] = bool(v) if isinstance(DEFAUTS[k], bool) else str(v)
    APP_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FICHIER.write_text(json.dumps(c, ensure_ascii=False, indent=2), encoding="utf-8")
    return c


# ── Outils externes : ffmpeg + moteur JavaScript (YouTube l'exige) ──────────────
def trouver_ffmpeg() -> str | None:
    nom = "ffmpeg.exe" if WINDOWS else "ffmpeg"
    candidats = [shutil.which("ffmpeg"), str(APP_DIR / "ffmpeg" / "bin" / nom), str(APP_DIR / "ffmpeg" / nom)]
    if WINDOWS:
        la = os.environ.get("LOCALAPPDATA", "")
        candidats.append(os.path.join(la, "Microsoft", "WinGet", "Links", "ffmpeg.exe"))
        candidats += glob.glob(os.path.join(la, "Microsoft", "WinGet", "Packages", "*FFmpeg*", "*", "bin", "ffmpeg.exe"))
        candidats += glob.glob(str(APP_DIR / "ffmpeg" / "*" / "bin" / "ffmpeg.exe"))
        candidats += [r"C:\ffmpeg\bin\ffmpeg.exe", r"C:\Program Files\ffmpeg\bin\ffmpeg.exe"]
    for c in candidats:
        if c and os.path.isfile(c):
            return c
    return None


def moteurs_js() -> dict:
    m: dict = {}
    for nom in ("deno", "node", "bun"):
        exe = shutil.which(nom) or (str(APP_DIR / f"{nom}.exe") if WINDOWS and (APP_DIR / f"{nom}.exe").is_file() else None)
        if WINDOWS and not exe and nom == "deno":
            la = os.environ.get("LOCALAPPDATA", "")
            for c in [os.path.join(la, "Microsoft", "WinGet", "Links", "deno.exe")] + glob.glob(os.path.join(la, "Microsoft", "WinGet", "Packages", "*Deno*", "deno.exe")):
                if os.path.isfile(c):
                    exe = c
                    break
        if exe:
            m[nom] = {"path": exe}
    return m


def ytdlp():
    import yt_dlp
    return yt_dlp


def options_base(**plus) -> dict:
    o = {"quiet": True, "no_warnings": True, "noprogress": True, "noplaylist": True, "socket_timeout": 20, "retries": 5, "fragment_retries": 5,
         "windowsfilenames": True, "trim_file_name": 150, "cachedir": str(APP_DIR / "cache"),
         "concurrent_fragment_downloads": 4, "http_chunk_size": 10 * 1024 * 1024}  # plus rapide : plusieurs morceaux en parallèle, pas de bridage YouTube
    js = moteurs_js()
    if js:
        o["js_runtimes"] = js
        o["remote_components"] = ["ejs:github"]
    ff = trouver_ffmpeg()
    if ff:
        o["ffmpeg_location"] = ff
    o.update(plus)
    return o


class _Log:
    def debug(self, m):
        pass

    def info(self, m):
        pass

    def warning(self, m):
        journal("yt-dlp:", m)

    def error(self, m):
        journal("yt-dlp ERREUR:", m)


def site_de(url: str) -> str:
    u = url.lower()
    return "tiktok" if "tiktok.com" in u else "youtube" if ("youtube.com" in u or "youtu.be" in u) else "autre"


def nettoyer_url(url: str) -> str:
    """Retire les paramètres inutiles (playlist, timestamp…) pour ne télécharger que la vidéo."""
    url = (url or "").strip()
    m = re.match(r"https?://(?:www\.|m\.|music\.)?youtube\.com/(?:watch\?(?:.*&)?v=|shorts/|live/)([\w-]{11})", url)
    if m:
        return f"https://www.youtube.com/watch?v={m.group(1)}" if "/shorts/" not in url else f"https://www.youtube.com/shorts/{m.group(1)}"
    m = re.match(r"https?://youtu\.be/([\w-]{11})", url)
    if m:
        return f"https://www.youtube.com/watch?v={m.group(1)}"
    return url.split("#")[0]


_BRUIT_TITRE = re.compile(r"\s*[\(\[\{][^\)\]\}]*\b(?:official|officiel|officielle|lyrics?|paroles|audio|video|vid[ée]o|clip|hd|hq|4k|8k|mv|visuali[sz]er|remaster(?:ed)?)\b[^\)\]\}]*[\)\]\}]", re.I)


def titre_propre(t: str) -> str:
    """« Artiste - Titre (Clip Officiel) [HD] » -> « Artiste - Titre »."""
    t = _BRUIT_TITRE.sub("", t or "")
    t = re.sub(r"\s*[|｜]\s*(?:official|officiel|lyrics?|audio).*$", "", t, flags=re.I)
    return re.sub(r"\s{2,}", " ", t).strip(" -–|")


def message_erreur(e: Exception) -> str:
    t = re.sub(r"\x1b\[[0-9;]*m", "", str(e)).replace("ERROR: ", "").strip()
    bas = t.lower()
    if "sign in to confirm" in bas or "confirm you" in bas:
        return "YouTube demande une connexion (vidéo protégée ou trop de téléchargements). Réessaie plus tard."
    if "private video" in bas or "video unavailable" in bas or "this video is not available" in bas:
        return "Vidéo privée ou indisponible."
    if "age" in bas and "restrict" in bas:
        return "Vidéo réservée aux adultes : YouTube bloque le téléchargement sans connexion."
    if "ffmpeg" in bas and ("not found" in bas or "not installed" in bas):
        return "ffmpeg manque : relance INSTALLER.bat."
    if "unable to download" in bas or "timed out" in bas or "connection" in bas:
        return "Problème de connexion internet. Réessaie."
    if "javascript" in bas or "js runtime" in bas or "n challenge" in bas or "signature" in bas:
        maj_en_arriere_plan(forcer=True)
        return "YouTube a changé quelque chose : je mets yt-dlp à jour tout seul, réessaie dans une minute (↻)."
    if "http error 429" in bas or "too many requests" in bas:
        return "Trop de téléchargements d'un coup pour ce site. Attends un peu puis réessaie (↻)."
    if "ffmpeg" in bas and "postprocess" in bas:
        return "La conversion a échoué (ffmpeg). Relance INSTALLER.bat."
    return t.splitlines()[0][:220] if t else "Erreur inconnue."


# ── Infos d'une vidéo (titre, miniature, qualités disponibles) ──────────────────
_cache_infos: dict[str, tuple[float, dict]] = {}


def infos(url: str) -> dict:
    url = nettoyer_url(url)
    if url in _cache_infos and time.time() - _cache_infos[url][0] < 600:
        return _cache_infos[url][1]
    yd = ytdlp()
    with yd.YoutubeDL(options_base(logger=_Log(), skip_download=True)) as y:
        i = y.extract_info(url, download=False)
    if i.get("_type") == "playlist" and i.get("entries"):
        i = next((e for e in i["entries"] if e), i)
    hauteurs = sorted({int(f["height"]) for f in i.get("formats") or [] if f.get("height") and f.get("vcodec") not in (None, "none")}, reverse=True)
    vign = i.get("thumbnail")
    if not vign and i.get("thumbnails"):
        vign = i["thumbnails"][-1].get("url")
    out = {"url": url, "titre": i.get("title") or i.get("description", "")[:80] or "Vidéo", "auteur": i.get("uploader") or i.get("channel") or i.get("creator"),
           "duree": i.get("duration"), "vignette": vign, "hauteurs": hauteurs, "site": site_de(url), "video_id": i.get("id"),
           "audio_seul": bool(i.get("formats")) and all(f.get("vcodec") == "none" for f in i["formats"])}
    _cache_infos[url] = (time.time(), out)
    return out


# ── Téléchargement ──────────────────────────────────────────────────────────────
def _evenement(job: dict, force: bool = False) -> None:
    t = time.time()
    if not force and t - job.get("_dernier", 0) < 0.25:
        return
    job["_dernier"] = t
    envoyer({"event": "job", "job": {k: v for k, v in job.items() if not k.startswith("_")}})


class Annule(Exception):
    pass


def _nom_sur(t: str) -> str:
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", t or "").strip(" .")[:80] or "Playlist"


def _modele_nom(c: dict, site: str, fmt: str, qualite: str, liste: str | None = None) -> str:
    if fmt == "mp3" and c.get("titres_propres", True) and not c.get("auteur_dans_nom") and site != "tiktok":
        base = "%(artist&{} - |)s%(title).120B"
    elif site == "tiktok":
        base = "%(uploader,creator,channel|TikTok)s - %(title,description|vidéo).70B [%(id)s]"
    elif c.get("auteur_dans_nom"):
        base = "%(uploader,channel|YouTube)s - %(title).110B"
    else:
        base = "%(title).130B"
    if fmt == "mp4" and qualite != "best":
        base += f" ({qualite}p)"
    dossier = Path(c["dossier"])
    if c.get("sous_dossiers"):
        dossier = dossier / ("Musique" if fmt == "mp3" else "Vidéos")
    if liste:
        dossier = dossier / _nom_sur(liste)
    return str(dossier / (base + ".%(ext)s"))


def telecharger(job: dict) -> None:
    yd = ytdlp()
    c = config()
    fmt, qualite = job["format"], job["qualite"]
    url = nettoyer_url(job["url"])
    site = site_de(url)
    ff = trouver_ffmpeg()
    parties = {"n": 1, "i": 0}

    def hook(d):
        if job.get("_annule"):
            raise Annule()
        if d["status"] == "downloading":
            info = d.get("info_dict") or {}
            parties["n"] = max(1, len(info.get("requested_formats") or [1]))
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            frac = (d.get("downloaded_bytes") or 0) / total if total else 0
            job.update(etat="telechargement", pct=round(min(0.999, (parties["i"] + frac) / parties["n"]) * 92, 1),
                       vitesse=d.get("speed"), eta=d.get("eta"), taille=total or job.get("taille"))
            if not job.get("titre") and info.get("title"):
                job["titre"] = info["title"]
            _evenement(job)
        elif d["status"] == "finished":
            parties["i"] += 1

    def pp_hook(d):
        if job.get("_annule"):
            raise Annule()
        if d.get("status") == "started" and d.get("postprocessor") in ("ExtractAudio", "Merger", "EmbedThumbnail", "FFmpegMetadata", "Metadata"):
            noms = {"ExtractAudio": "Conversion en MP3…", "Merger": "Assemblage image + son…", "EmbedThumbnail": "Ajout de la pochette…"}
            job.update(etat="conversion", pct=max(job.get("pct") or 0, 94), etape=noms.get(d["postprocessor"], "Finalisation…"), vitesse=None, eta=None)
            _evenement(job, True)

    o = options_base(logger=_Log(), progress_hooks=[hook], postprocessor_hooks=[pp_hook], outtmpl=_modele_nom(c, site, fmt, qualite, job.get("liste")),
                     overwrites=False, continuedl=True)
    if str(c.get("limite_vitesse", "0")) != "0":
        o["ratelimit"] = int(c["limite_vitesse"]) * 1024 * 1024
    pps = []
    if c.get("titres_propres", True) and site != "tiktok":  # pré-traitement : retire « (Clip Officiel) », sépare artiste / titre
        from yt_dlp.postprocessor.metadataparser import MetadataParserPP as MP
        pps.append({"key": "MetadataParser", "when": "pre_process", "actions": [
            (MP.replacer, "title", _BRUIT_TITRE.pattern, ""),
            (MP.interpretter, "title", r"^(?P<artist>[^-–]{2,60}?)\s+[-–]\s+(?P<title>.+)$")]})
    if fmt == "mp3":
        if not ff:
            raise RuntimeError("ffmpeg manque pour créer des MP3 : relance INSTALLER.bat.")
        o["format"] = "ba/b"  # le meilleur flux audio (souvent Opus ~160 kb/s, meilleur que le m4a 128)
        o["format_sort"] = ["abr", "asr"]
        pps.append({"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": qualite if qualite in QUALITES_AUDIO else "320"})
        pps.append({"key": "FFmpegMetadata", "add_metadata": True})
        if c.get("pochette", True):
            o["writethumbnail"] = True
            pps.insert(0, {"key": "FFmpegThumbnailsConvertor", "format": "jpg", "when": "before_dl"})
            pps.append({"key": "EmbedThumbnail", "already_have_thumbnail": False})
    else:
        h = "" if qualite == "best" else f"[height<={qualite}]"
        if ff:
            o["format"] = f"bv*{h}+ba/b{h}/bv*+ba/b"
            o["format_sort"] = [f"res:{qualite}" if qualite != "best" else "res", "fps", "vcodec:h264", "acodec:m4a", "ext:mp4:m4a"]
            o["merge_output_format"] = "mp4"
            pps.append({"key": "FFmpegMetadata", "add_metadata": True})
            if c.get("sous_titres"):
                o.update(writesubtitles=True, subtitleslangs=["fr.*", "en.*"])
                pps.append({"key": "FFmpegEmbedSubtitle"})
        else:  # sans ffmpeg : seulement les formats déjà complets
            o["format"] = f"b{h}[ext=mp4]/b{h}/b"
    if c.get("sponsorblock") and site == "youtube":  # coupe les sponsors / « abonnez-vous » (YouTube seulement)
        cats = ["sponsor", "selfpromo", "interaction"]
        pps.insert(0, {"key": "SponsorBlock", "categories": cats, "when": "after_filter"})
        pps.append({"key": "ModifyChapters", "remove_sponsor_segments": cats, "remove_chapters_patterns": [], "remove_ranges": [], "sponsorblock_chapter_title": "", "force_keyframes": False})
    o["postprocessors"] = pps
    job.update(etat="telechargement", pct=0.5, etape=None)
    _evenement(job, True)
    with yd.YoutubeDL(o) as y:
        info = y.extract_info(url, download=True)
    if job.get("_annule"):
        raise Annule()
    if info.get("_type") == "playlist" and info.get("entries"):
        info = next((e for e in info["entries"] if e), info)
    chemin = None
    for r in info.get("requested_downloads") or []:
        chemin = r.get("filepath") or r.get("_filename") or chemin
    if not chemin or not os.path.exists(chemin):
        base = os.path.splitext(y.prepare_filename(info))[0]
        for ext in ("mp3", "mp4", "mkv", "webm", "m4a"):
            if os.path.exists(f"{base}.{ext}"):
                chemin = f"{base}.{ext}"
                break
    if not chemin or not os.path.exists(chemin):
        raise RuntimeError("Le fichier final est introuvable.")
    job.update(etat="fini", pct=100, fichier=chemin, nom=os.path.basename(chemin), taille=os.path.getsize(chemin), titre=info.get("title") or job.get("titre"),
               vignette=job.get("vignette") or info.get("thumbnail"), etape=None, vitesse=None, eta=None, fin=time.time())


def lancer_job(msg: dict) -> dict:
    fmt = "mp3" if msg.get("format") == "mp3" else "mp4"
    c = config()
    q = str(msg.get("qualite") or (c["qualite_audio"] if fmt == "mp3" else c["qualite_video"]))
    if fmt == "mp4" and q not in QUALITES_VIDEO:
        q = "best"
    if fmt == "mp3" and q not in QUALITES_AUDIO:
        q = "320"
    url = str(msg.get("url") or "")
    if not re.match(r"^https?://", url):
        raise ValueError("Lien invalide.")
    jid = f"{int(time.time() * 1000):x}{os.urandom(2).hex()}"
    job = {"id": jid, "url": url, "format": fmt, "qualite": q, "titre": msg.get("titre"), "vignette": msg.get("vignette"), "site": site_de(url),
           "etat": "attente", "pct": 0, "debut": time.time(), "fichier": None, "erreur": None, "liste": (str(msg.get("liste"))[:80] if msg.get("liste") else None)}
    _jobs[jid] = job

    def travail():
        try:
            with _cond:  # file d'attente : au plus N téléchargements en même temps (réglage), le reste patiente
                while _en_cours["n"] >= int(config().get("simultanes", "2")) and not job.get("_annule"):
                    _cond.wait(0.5)
                _en_cours["n"] += 1
            try:
                if job.get("_annule"):
                    raise Annule()
                telecharger(job)
            except Annule:
                job.update(etat="annule", erreur="Annulé", pct=0)
            except Exception as e:  # noqa: BLE001
                journal("Échec", job["url"], traceback.format_exc())
                job.update(etat="erreur", erreur=message_erreur(e))
            finally:
                with _cond:
                    _en_cours["n"] -= 1
                    _cond.notify_all()
        finally:
            _evenement(job, True)
    threading.Thread(target=travail, daemon=True).start()
    _evenement(job, True)
    return {k: v for k, v in job.items() if not k.startswith("_")}


# ── Mises à jour de Salopar DL lui-même (signées : seul le propriétaire peut publier) ──────────
CLE_PUBLIQUE = "xs6Tgc9PfyXvZ5XVVSbnyosrhWsDlRtaMui2AuhW2pA="


def version_tuple(v: str) -> tuple:
    return tuple(int(x) for x in re.findall(r"\d+", v or "0")[:4]) or (0,)


def url_maj() -> str:
    for f in (APP_DIR / "update.json", Path(__file__).with_name("update.json")):
        try:
            u = str(json.loads(f.read_text(encoding="utf-8-sig")).get("url") or "").strip()
            if u:
                return u
        except (OSError, ValueError):
            continue
    return ""


def _http(url: str, delai: int = 20, max_octets: int = 60_000_000) -> bytes:
    local = re.match(r"^http://(127\.0\.0\.1|localhost)[:/]", url or "")
    if not (url.startswith("https://") or local):
        raise ValueError("L'adresse des mises à jour doit commencer par https://")
    req = urllib.request.Request(url, headers={"User-Agent": "SaloparDL/" + VERSION, "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=delai) as r:
        data = r.read(max_octets + 1)
    if len(data) > max_octets:
        raise ValueError("Fichier de mise à jour trop gros.")
    return data


def _verifier_signature(version: str, sha256: str, signature_b64: str) -> None:
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    except ImportError:
        kw = {"creationflags": 0x08000000} if WINDOWS else {}
        subprocess.run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "cryptography"], capture_output=True, timeout=300, **kw)
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    cle = Ed25519PublicKey.from_public_bytes(base64.b64decode(CLE_PUBLIQUE))
    cle.verify(base64.b64decode(signature_b64), f"salopar-dl|{version}|{sha256}".encode())  # lève une exception si faux


def _lire_version_json(url: str) -> dict:
    """Lit version.json en expliquant clairement ce qui ne va pas (dépôt privé, fichier absent, pas d'internet…)."""
    import urllib.error
    try:
        return json.loads(_http(url, 12, 200_000).decode("utf-8-sig"))
    except urllib.error.HTTPError as e:
        if e.code in (404, 403):
            raise ValueError(f"version.json introuvable ({e.code}) : le dépôt GitHub doit être PUBLIC et contenir version.json.")
        raise ValueError(f"Le serveur des mises à jour répond une erreur ({e.code}).")
    except (urllib.error.URLError, TimeoutError, OSError):
        raise ValueError("Impossible de joindre le serveur des mises à jour (pas d'internet ?).")
    except ValueError:
        raise ValueError("version.json est illisible : republie la mise à jour avec PUBLIER.bat.")


def maj_verifier() -> dict:
    """Y a-t-il une nouvelle version de Salopar DL ? (lit le fichier version.json signé du propriétaire)"""
    url = url_maj()
    if not url:
        return {"configure": False, "dispo": False, "courante": VERSION}
    v = _lire_version_json(url)
    nouvelle = str(v.get("version") or "0")
    return {"configure": True, "dispo": version_tuple(nouvelle) > version_tuple(VERSION), "courante": VERSION, "version": nouvelle,
            "notes": str(v.get("notes") or "")[:600], "auto": bool(v.get("auto")), "obligatoire": bool(v.get("obligatoire"))}


def maj_appliquer() -> dict:
    """Télécharge la mise à jour, vérifie la signature, remplace l'extension et le programme. Chrome recharge ensuite l'extension."""
    url = url_maj()
    if not url:
        raise ValueError("Les mises à jour ne sont pas configurées.")
    v = _lire_version_json(url)
    version = str(v.get("version") or "")
    if version_tuple(version) <= version_tuple(VERSION):
        return {"version": VERSION, "deja": True}
    zurl = str(v.get("zip") or "")
    if not zurl.startswith(("https://", "http://127.0.0.1", "http://localhost")):
        zurl = url.rsplit("/", 1)[0] + "/" + zurl.lstrip("/")
    data = _http(zurl, 120)
    sha = hashlib.sha256(data).hexdigest()
    if sha != str(v.get("sha256") or ""):
        raise ValueError("Mise à jour corrompue (empreinte différente) : rien n'a été modifié.")
    try:
        _verifier_signature(version, sha, str(v.get("signature") or ""))
    except Exception:  # noqa: BLE001
        raise ValueError("Signature invalide : cette mise à jour ne vient pas du propriétaire. Rien n'a été modifié.")
    z = zipfile.ZipFile(io.BytesIO(data))
    fichiers = {}
    for info in z.infolist():
        nom = info.filename.replace("\\", "/")
        if info.is_dir():
            continue
        if nom.startswith("/") or ".." in nom.split("/") or not (nom.startswith("extension/") or nom == "host.py"):
            raise ValueError("Mise à jour refusée : elle contient un fichier inattendu (" + nom[:60] + ").")
        fichiers[nom] = z.read(info)
    if "extension/manifest.json" not in fichiers or "host.py" not in fichiers:
        raise ValueError("Mise à jour incomplète.")
    compile(fichiers["host.py"], "host.py", "exec")  # le nouveau programme doit au moins être du Python valide
    ext = APP_DIR / "extension"
    autres = []  # autres dossiers où l'extension a été chargée dans Chrome (écrits par INSTALLER.bat) : on les met à jour aussi
    try:
        for d in json.loads((APP_DIR / "chemins.json").read_text(encoding="utf-8-sig")).get("extensions", []):
            pd = Path(d)
            if pd.is_dir() and (pd / "manifest.json").is_file() and pd.resolve() != ext.resolve():
                autres.append(pd)
    except (OSError, ValueError):
        pass
    sauvegarde = APP_DIR / "sauvegarde"
    shutil.rmtree(sauvegarde, ignore_errors=True)
    sauvegarde.mkdir(parents=True, exist_ok=True)
    if ext.is_dir():
        shutil.copytree(ext, sauvegarde / "extension")
    if (APP_DIR / "host.py").is_file():
        shutil.copy2(APP_DIR / "host.py", sauvegarde / "host.py")
    ext.mkdir(parents=True, exist_ok=True)
    voulus = set()
    for nom, contenu in fichiers.items():
        if nom == "host.py":
            continue
        cible = APP_DIR / nom
        cible.parent.mkdir(parents=True, exist_ok=True)
        cible.write_bytes(contenu)
        voulus.add(cible.resolve())
    for f in list(ext.rglob("*")):  # fichiers supprimés dans la nouvelle version
        if f.is_file() and f.resolve() not in voulus:
            f.unlink(missing_ok=True)
    for pd in autres:
        try:
            for nom, contenu in fichiers.items():
                if nom.startswith("extension/"):
                    cible = pd / nom[len("extension/"):]
                    cible.parent.mkdir(parents=True, exist_ok=True)
                    cible.write_bytes(contenu)
        except OSError as e:
            journal("Mise à jour : dossier non modifiable", pd, e)
    nouveau = APP_DIR / "host.py.new"
    nouveau.write_bytes(fichiers["host.py"])
    os.replace(nouveau, APP_DIR / "host.py")
    journal("Mise à jour appliquée :", VERSION, "->", version)
    return {"version": version, "deja": False}


# ── Playlists ──────────────────────────────────────────────────────────────────
def playlist(url: str) -> dict:
    m = re.search(r"[?&]list=([\w-]+)", url or "")
    if m:
        url = f"https://www.youtube.com/playlist?list={m.group(1)}"
    yd = ytdlp()
    with yd.YoutubeDL(options_base(logger=_Log(), skip_download=True, extract_flat="in_playlist", noplaylist=False, playlistend=150)) as y:
        i = y.extract_info(url, download=False)
    entrees = []
    for e in i.get("entries") or []:
        if not e or not e.get("id"):
            continue
        u = e.get("url") or e.get("webpage_url") or ""
        if not u.startswith("http"):
            u = f"https://www.youtube.com/watch?v={e['id']}"
        vign = e.get("thumbnail") or ((e.get("thumbnails") or [{}])[-1].get("url") if e.get("thumbnails") else None)
        entrees.append({"url": u, "titre": e.get("title") or "Vidéo", "duree": e.get("duration"), "vignette": vign})
    if not entrees:
        raise ValueError("Cette playlist est vide ou privée.")
    return {"titre": i.get("title") or "Playlist", "total": len(entrees), "entrees": entrees}


# ── Mise à jour automatique de yt-dlp (YouTube change souvent) ─────────────────
_maj_verrou = threading.Lock()


def maj_en_arriere_plan(forcer: bool = False) -> None:
    fichier = APP_DIR / "maj.json"

    def travail():
        if not _maj_verrou.acquire(blocking=False):
            return
        try:
            try:
                dernier = json.loads(fichier.read_text(encoding="utf-8")).get("ts", 0)
            except (OSError, ValueError):
                dernier = 0
            if time.time() - dernier < (3600 if forcer else 7 * 86400):
                return
            if not forcer and not config().get("maj_auto", True):
                return
            journal("Mise à jour automatique de yt-dlp…")
            try:
                v = mettre_a_jour()
                journal("yt-dlp", v)
            except Exception as e:  # noqa: BLE001
                journal("Mise à jour auto impossible", e)
            APP_DIR.mkdir(parents=True, exist_ok=True)
            fichier.write_text(json.dumps({"ts": time.time()}), encoding="utf-8")
        finally:
            _maj_verrou.release()
    threading.Thread(target=travail, daemon=True).start()


# ── Ouvrir / dossier / choisir un dossier ───────────────────────────────────────
def ouvrir(chemin: str, dossier: bool = False) -> None:
    if not chemin or not os.path.exists(chemin):
        raise ValueError("Fichier introuvable (déplacé ou supprimé ?).")
    if WINDOWS:
        if dossier:
            subprocess.Popen(["explorer", "/select,", os.path.normpath(chemin)])
        else:
            os.startfile(chemin)  # noqa: S606
    elif platform.system() == "Darwin":
        subprocess.Popen(["open", "-R", chemin] if dossier else ["open", chemin])
    else:
        subprocess.Popen(["xdg-open", os.path.dirname(chemin) if dossier else chemin], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def chemin_autorise(chemin: str, job: dict | None) -> bool:
    """On n'ouvre que des fichiers téléchargés par Salopar DL (dans son dossier)."""
    if not chemin or not os.path.exists(chemin):
        return False
    if job is not None and job.get("fichier") == chemin:
        return True
    p = Path(chemin).resolve()
    base = Path(config()["dossier"]).resolve()
    return p.suffix.lower() in (".mp3", ".mp4", ".mkv", ".webm", ".m4a") and (base == p.parent or base in p.parents)


def choisir_dossier(depart: str) -> str | None:
    """Fenêtre Windows « Choisir un dossier » (dans un processus à part pour ne rien bloquer)."""
    code = ("import tkinter as tk, sys\nfrom tkinter import filedialog\nr = tk.Tk(); r.withdraw(); r.attributes('-topmost', True)\n"
            "p = filedialog.askdirectory(initialdir=sys.argv[1], title='Où enregistrer les téléchargements ?', mustexist=False)\n"
            "print(p or '')")
    exe = sys.executable
    if WINDOWS and exe.lower().endswith("python.exe") and os.path.exists(exe[:-10] + "pythonw.exe"):
        exe = exe[:-10] + "pythonw.exe"
    r = subprocess.run([exe, "-c", code, depart], capture_output=True, text=True, timeout=600)
    p = (r.stdout or "").strip()
    return p or None


def mettre_a_jour() -> str:
    kw = {"creationflags": 0x08000000} if WINDOWS else {}  # pas de fenêtre noire qui clignote
    r = subprocess.run([sys.executable, "-m", "pip", "install", "-U", "--disable-pip-version-check", "yt-dlp[default]"], capture_output=True, text=True, timeout=600, **kw)
    if r.returncode != 0:
        raise RuntimeError("Mise à jour impossible : " + (r.stderr or r.stdout)[-200:])
    return subprocess.run([sys.executable, "-c", "import yt_dlp.version as v; print(v.__version__)"], capture_output=True, text=True, **kw).stdout.strip()


def etat() -> dict:
    try:
        import yt_dlp.version
        v = yt_dlp.version.__version__
    except Exception:
        v = None
    c = config()
    try:
        ext_v = json.loads((APP_DIR / "extension" / "manifest.json").read_text(encoding="utf-8")).get("version")
    except (OSError, ValueError):
        ext_v = None
    return {"dossier_extension": str(APP_DIR / "extension"), "version_extension_installee": ext_v, "version": VERSION, "ytdlp": v, "ffmpeg": bool(trouver_ffmpeg()), "js": sorted(moteurs_js()), "config": c, "os": platform.system(),
            "jobs": [{k: v for k, v in j.items() if not k.startswith("_")} for j in _jobs.values()]}


# ── Boucle principale ───────────────────────────────────────────────────────────
def traiter(msg: dict) -> None:
    rid, cmd = msg.get("id"), msg.get("cmd")
    try:
        if cmd == "ping":
            rep = etat()
        elif cmd == "info":
            rep = infos(str(msg.get("url") or ""))
        elif cmd == "download":
            rep = {"job": lancer_job(msg)}
        elif cmd == "maj_check":
            rep = maj_verifier()
        elif cmd == "maj_apply":
            rep = maj_appliquer()
        elif cmd == "playlist":
            rep = playlist(str(msg.get("url") or ""))
        elif cmd == "cancel_all":
            for j in _jobs.values():
                if j["etat"] in ("attente", "telechargement", "conversion"):
                    j["_annule"] = True
            rep = {}
        elif cmd == "cancel":
            j = _jobs.get(str(msg.get("job")))
            if j is not None:
                j["_annule"] = True
            rep = {}
        elif cmd in ("open", "folder"):
            j = _jobs.get(str(msg.get("job") or ""))
            chemin = j["fichier"] if j and j.get("fichier") else str(msg.get("fichier") or "")
            if cmd == "folder" and not chemin:
                d = config()["dossier"]
                Path(d).mkdir(parents=True, exist_ok=True)
                chemin = d
                ouvrir(chemin, False)
            else:
                if not chemin_autorise(chemin, j):
                    raise ValueError("Fichier introuvable (déplacé ou supprimé ?).")
                ouvrir(chemin, cmd == "folder")
            rep = {}
        elif cmd == "choose_folder":
            p = choisir_dossier(config()["dossier"])
            rep = {"config": sauver_config({"dossier": p}) if p else config(), "change": bool(p)}
        elif cmd == "config":
            rep = {"config": sauver_config(msg.get("config") or {})}
        elif cmd == "update":
            rep = {"ytdlp": mettre_a_jour()}
        else:
            raise ValueError(f"Commande inconnue : {cmd}")
        envoyer({**rep, "id": rid, "ok": True})
    except Exception as e:  # noqa: BLE001
        journal("Commande", cmd, traceback.format_exc())
        envoyer({"id": rid, "ok": False, "erreur": message_erreur(e) if cmd in ("info", "download") else str(e)})


def main() -> None:
    _binaire()
    journal("Démarrage", VERSION, sys.executable)
    maj_en_arriere_plan()
    while True:
        msg = lire()
        if msg is None:
            break
        lent = msg.get("cmd") in ("info", "update", "choose_folder", "playlist", "maj_check", "maj_apply")
        if lent:
            threading.Thread(target=traiter, args=(msg,), daemon=True).start()
        else:
            traiter(msg)
    # Chrome a fermé la connexion : on laisse finir les téléchargements en cours
    while any(j["etat"] in ("attente", "telechargement", "conversion") for j in _jobs.values()):
        time.sleep(0.5)


if __name__ == "__main__":
    main()
