'use strict';
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const taille = o => !o ? '' : o > 1073741824 ? (o / 1073741824).toFixed(2).replace('.', ',') + ' Go' : o > 1048576 ? (o / 1048576).toFixed(1).replace('.', ',') + ' Mo' : Math.max(1, Math.round(o / 1024)) + ' Ko';
const mmss = s => { s = Math.round(s || 0); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
const NOMS_Q = { best: 'Meilleure qualité', 2160: '4K', 1440: '2K', 1080: '1080p', 720: '720p', 480: '480p', 360: '360p' };
let statut = null, ongletUrl = null, ongletInfos = {};
const jobs = new Map();

async function envoyer(type, data = {}) {
  const r = await chrome.runtime.sendMessage({ type, ...data });
  if (!r?.ok) throw new Error(r?.erreur || 'Erreur');
  return r;
}
function flash(el, texte) { const avant = el.textContent; el.textContent = texte; setTimeout(() => { el.textContent = avant; }, 1600); }

async function chargerStatut() {
  const e = $('#etat');
  e.textContent = '…'; e.className = 'pilule';
  try { statut = await envoyer('statut'); } catch (x) { statut = { ok: false, erreur: x.message }; }
  if (!statut.ok) {
    e.textContent = 'Non installé'; e.className = 'pilule ko';
    $('#absent').hidden = false; $('#absent-txt').textContent = statut.erreur || $('#absent-txt').textContent;
    $('#versions').textContent = 'Programme introuvable';
    return;
  }
  $('#absent').hidden = true;
  e.textContent = statut.ffmpeg ? '● Prêt' : '⚠ ffmpeg manquant'; e.className = 'pilule ' + (statut.ffmpeg ? 'ok' : 'ko');
  $('#versions').textContent = `yt-dlp ${statut.ytdlp || '?'} · ffmpeg ${statut.ffmpeg ? '✓' : '✗'} · YouTube ${statut.js?.length ? '✓' : '⚠'}`;
  const c = statut.config;
  if (document.activeElement !== $('#r-dossier')) $('#r-dossier').value = c.dossier;
  $('#r-qv').value = c.qualite_video; $('#r-qa').value = c.qualite_audio;
  $('#r-pochette').checked = !!c.pochette; $('#r-sous').checked = !!c.sous_dossiers; $('#r-auteur').checked = !!c.auteur_dans_nom;
  $('#r-sim').value = c.simultanes; $('#r-vit').value = c.limite_vitesse;
  $('#r-propres').checked = !!c.titres_propres; $('#r-st').checked = !!c.sous_titres; $('#r-sb').checked = !!c.sponsorblock; $('#r-maj').checked = !!c.maj_auto;
  $('#o-qa').textContent = $('#o-sa').value + ' kbps'; majHauteurs(ongletInfos.hauteurs);
  if (derniereMaj) etatMaj(derniereMaj);
}
/* Liste de qualités vidéo réellement disponibles pour CETTE vidéo (sinon la liste complète) */
function majHauteurs(hauteurs) {
  const c = statut?.config || {};
  const dispo = (hauteurs || []).filter(h => [2160, 1440, 1080, 720, 480, 360].includes(h) || h > 360);
  const choix = [['best', hauteurs?.length ? `Meilleure (${Math.max(...hauteurs)}p)` : 'Meilleure']];
  const liste = hauteurs?.length ? [2160, 1440, 1080, 720, 480, 360].filter(q => hauteurs.some(h => h >= q - 20 && h <= q + 20 || h >= q)) : [2160, 1440, 1080, 720, 480, 360];
  for (const q of liste) choix.push([String(q), q >= 2160 ? '4K (2160p)' : q === 1440 ? '2K (1440p)' : `${q}p`]);
  const avant = $('#o-sv').value || String(c.qualite_video || 'best');
  $('#o-sv').innerHTML = choix.map(([v, t]) => `<option value="${v}">${t}</option>`).join('');
  $('#o-sv').value = choix.some(([v]) => v === avant) ? avant : 'best';
  $('#o-qv').textContent = $('#o-sv').selectedOptions[0]?.textContent || 'Meilleure';
  void dispo;
}

async function chargerOnglet() {
  let [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (await chrome.tabs.getCurrent()) t = (await chrome.tabs.query({})).filter(x => /^https?:/.test(x.url || '')).sort((x, y) => (y.lastAccessed || 0) - (x.lastAccessed || 0))[0] || t;  // popup ouvert dans un onglet
  if (!t) return;
  let url = null;
  try { url = (await chrome.tabs.sendMessage(t.id, { type: 'url_courante' }))?.url; } catch { /* pas une page YouTube/TikTok */ }
  if (!url && /youtube\.com\/(watch|shorts)|tiktok\.com\/.+\/video\//.test(t.url || '')) url = t.url;
  if (!url) return;
  ongletUrl = url;
  const id = (url.match(/(?:v=|\/shorts\/)([\w-]{11})/) || [])[1];
  ongletInfos = { titre: (t.title || '').replace(/^\(\d+\)\s*/, '').replace(/ - YouTube$| \| TikTok$/, ''), vignette: id ? `https://i.ytimg.com/vi/${id}/mqdefault.jpg` : null };
  $('#onglet').hidden = false;
  $('#o-titre').textContent = ongletInfos.titre || 'Cette vidéo';
  $('#o-site').textContent = /tiktok/.test(url) ? 'TikTok' : /shorts/.test(url) ? 'YouTube Shorts' : 'YouTube';
  if (ongletInfos.vignette) $('#o-vign').style.backgroundImage = `url("${ongletInfos.vignette}")`;
  $('#pl').hidden = !/youtube\.com\/.*[?&]list=/.test(t.url || url);
  enrichir(url);
}
/* Infos exactes (titre, chaîne, durée, miniature, qualités) demandées au programme : s'affichent dès qu'elles arrivent */
async function enrichir(url) {
  try {
    const i = await envoyer('info', { url });
    if (ongletUrl !== url) return;
    ongletInfos = { ...ongletInfos, titre: i.titre || ongletInfos.titre, vignette: i.vignette || ongletInfos.vignette, hauteurs: i.hauteurs };
    $('#o-titre').textContent = i.titre || ongletInfos.titre || 'Cette vidéo';
    $('#o-site').textContent = [i.auteur, i.duree ? mmss(i.duree) : null, /tiktok/.test(url) ? 'TikTok' : null].filter(Boolean).join(' · ') || $('#o-site').textContent;
    if (i.vignette) $('#o-vign').style.backgroundImage = `url("${i.vignette}")`;
    majHauteurs(i.hauteurs);
    if (i.audio_seul) { $('[data-f=mp4]').hidden = true; }
  } catch { /* les infos sont un plus : on garde ce qu'on a */ }
}
$('#o-sv').addEventListener('change', () => { $('#o-qv').textContent = $('#o-sv').selectedOptions[0].textContent; });
$('#o-sa').addEventListener('change', () => { $('#o-qa').textContent = $('#o-sa').value + ' kbps'; });
const qualiteChoisie = f => f === 'mp3' ? $('#o-sa').value : $('#o-sv').value;
$('#pl').addEventListener('click', async e => {
  const b = e.target.closest('[data-pl]'); if (!b || !ongletUrl) return;
  b.disabled = true; $('#pl-txt').textContent = '📃 Lecture de la playlist…';
  try {
    const pl = await envoyer('playlist', { url: (await chrome.tabs.query({ active: true, currentWindow: true }))[0]?.url || ongletUrl });
    $('#pl-txt').textContent = `📃 ${pl.total} vidéos`;
    if (confirm(`Télécharger les ${pl.total} vidéos de « ${pl.titre} » en ${b.dataset.pl.toUpperCase()} ?\nElles seront rangées dans un dossier à son nom.`))
      await envoyer('telecharger_liste', { entrees: pl.entrees, format: b.dataset.pl, qualite: qualiteChoisie(b.dataset.pl), nom: pl.titre });
  } catch (x) { alert(x.message); }
  $('#pl-txt').textContent = '📃 Playlist'; b.disabled = false;
});
/* coller un lien (n'importe quel site pris en charge par yt-dlp) */
$('#coller').addEventListener('submit', async e => {
  e.preventDefault();
  const url = $('#lien').value.trim(); const f = e.submitter?.dataset.c || 'mp4';
  if (!/^https?:\/\//i.test(url)) { $('#lien').focus(); return; }
  try { await envoyer('telecharger', { url, format: f, qualite: f === 'mp3' ? $('#o-sa').value : undefined }); $('#lien').value = ''; }
  catch (x) { alert(x.message); }
});
$('#onglet').addEventListener('click', async e => {
  const b = e.target.closest('[data-f]'); if (!b || !ongletUrl) return;
  b.disabled = true;
  try { await envoyer('telecharger', { url: ongletUrl, format: b.dataset.f, qualite: qualiteChoisie(b.dataset.f), titre: ongletInfos.titre, vignette: ongletInfos.vignette }); }
  catch (x) { alert(x.message); }
  b.disabled = false;
});

function etat(j) {
  if (j.etat === 'attente') return ['En attente…', ''];
  if (j.etat === 'telechargement') return [`${Math.floor(j.pct || 0)} %` + (j.vitesse ? ` · ${taille(j.vitesse)}/s` : '') + (j.eta ? ` · ${mmss(j.eta)}` : ''), ''];
  if (j.etat === 'conversion') return [j.etape || 'Finalisation…', ''];
  if (j.etat === 'fini') return [`✅ ${taille(j.taille)} · ${new Date((j.fin || j.debut) * 1000).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}`, 'ok'];
  if (j.etat === 'annule') return ['Annulé', 'ko'];
  return ['❌ ' + (j.erreur || 'Erreur'), 'ko'];
}
function dessiner() {
  const l = [...jobs.values()].sort((a, b) => (b.debut || 0) - (a.debut || 0));
  const actifs = l.filter(j => ['attente', 'telechargement', 'conversion'].includes(j.etat)).length, echecs = l.filter(j => j.etat === 'erreur').length;
  $('#tout-annuler').hidden = actifs < 2; $('#relancer-tout').hidden = echecs < 1;
  if (!l.length) { $('#liste').innerHTML = '<p class="vide">Rien pour l’instant. Ouvre une vidéo puis clique sur <b>MP4</b> / <b>MP3</b>, ou colle un lien.</p>'; return; }
  $('#liste').innerHTML = l.map(j => {
    const [t, cls] = etat(j), actif = ['attente', 'telechargement', 'conversion'].includes(j.etat);
    return `<div class="dl" data-id="${esc(j.id)}"><div class="vign" style="${j.vignette ? `background-image:url('${esc(j.vignette).replace(/'/g, '%27')}')` : ''}"></div>
      <div class="grow"><b><span class="tag ${j.format}">${j.format === 'mp3' ? 'MP3' : 'MP4'}</span>${esc(j.titre || j.nom || j.url)}</b><div class="etat ${cls}">${esc(t)}</div>
      ${actif ? `<div class="barre"><i style="width:${Math.max(2, j.pct || 0)}%"></i></div>` : ''}</div>
      <div class="acts">${actif ? '<button class="act" data-a="annuler" title="Annuler">✕</button>' : j.etat === 'fini' ? '<button class="act" data-a="ouvrir" title="Ouvrir">▶</button><button class="act" data-a="dossier" title="Dossier">📁</button>' : '<button class="act" data-a="relancer" title="Réessayer">↻</button>'}</div></div>`;
  }).join('');
}
$('#liste').addEventListener('click', async e => {
  const b = e.target.closest('[data-a]'); if (!b) return;
  const j = jobs.get(b.closest('.dl').dataset.id); if (!j) return;
  try {
    if (b.dataset.a === 'relancer') await envoyer('telecharger', { url: j.url, format: j.format, qualite: j.qualite, titre: j.titre, vignette: j.vignette });
    else await envoyer(b.dataset.a, { job: j.id });
  } catch (x) { alert(x.message); }
});
$('#dossier').addEventListener('click', () => envoyer('dossier').catch(x => alert(x.message)));
$('#vider').addEventListener('click', async () => {
  await envoyer('effacer', { jobs: [...jobs.values()].filter(j => !['attente', 'telechargement', 'conversion'].includes(j.etat)).map(j => j.id) });
});
$('#tout-annuler').addEventListener('click', () => envoyer('annuler_tout').catch(x => alert(x.message)));
$('#relancer-tout').addEventListener('click', async () => {
  for (const j of [...jobs.values()].filter(j => j.etat === 'erreur')) { try { await envoyer('telecharger', { url: j.url, format: j.format, qualite: j.qualite, titre: j.titre, vignette: j.vignette, liste: j.liste }); jobs.delete(j.id); } catch { /* suivant */ } }
  dessiner();
});
$('#reessayer').addEventListener('click', () => chargerStatut());

/* réglages */
async function majConfig(c) {
  try { const r = await envoyer('config', { config: c }); statut.config = r.config; } catch (x) { alert(x.message); }
  chargerStatut();
}
$('#r-qv').addEventListener('change', e => majConfig({ qualite_video: e.target.value }));
$('#r-qa').addEventListener('change', e => majConfig({ qualite_audio: e.target.value }));
$('#r-pochette').addEventListener('change', e => majConfig({ pochette: e.target.checked }));
$('#r-sous').addEventListener('change', e => majConfig({ sous_dossiers: e.target.checked }));
$('#r-auteur').addEventListener('change', e => majConfig({ auteur_dans_nom: e.target.checked }));
$('#r-sim').addEventListener('change', e => majConfig({ simultanes: e.target.value }));
$('#r-vit').addEventListener('change', e => majConfig({ limite_vitesse: e.target.value }));
$('#r-propres').addEventListener('change', e => majConfig({ titres_propres: e.target.checked }));
$('#r-st').addEventListener('change', e => majConfig({ sous_titres: e.target.checked }));
$('#r-sb').addEventListener('change', e => majConfig({ sponsorblock: e.target.checked }));
$('#r-maj').addEventListener('change', e => majConfig({ maj_auto: e.target.checked }));
const saveDossier = () => majConfig({ dossier: $('#r-dossier').value });
$('#r-ok').addEventListener('click', saveDossier);
$('#r-dossier').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); saveDossier(); } });
$('#r-changer').addEventListener('click', async e => {
  e.target.disabled = true; flash(e.target, 'Fenêtre ouverte…');
  try { await envoyer('choisir_dossier'); await chargerStatut(); } catch (x) { alert(x.message); }
  e.target.disabled = false;
});
chrome.storage.sync.get({ notifications: true }).then(r => { $('#r-notif').checked = r.notifications; });
$('#r-notif').addEventListener('change', e => chrome.storage.sync.set({ notifications: e.target.checked }));
$('#maj').addEventListener('click', async e => {
  e.target.disabled = true; e.target.textContent = 'Mise à jour…';
  try { const r = await envoyer('maj'); e.target.textContent = `✓ yt-dlp ${r.ytdlp}`; chargerStatut(); }
  catch (x) { e.target.textContent = 'Échec'; alert(x.message); }
  e.target.disabled = false;
});

/* progression en direct */
const port = chrome.runtime.connect({ name: 'sdl-vue' });
port.onMessage.addListener(m => {
  if (m.type === 'jobs') { jobs.clear(); for (const j of m.jobs) jobs.set(j.id, j); }
  if (m.type === 'job') jobs.set(m.job.id, m.job);
  dessiner();
});
/* nouvelle version de Salopar DL ? (le propriétaire publie, chacun clique « Mettre à jour ») */
function etatMaj(r) {
  const v = statut?.version || r?.courante || '';
  const e = $('#v-sdl'); e.className = '';
  const charge = chrome.runtime.getManifest().version;
  if (statut?.ok && charge !== statut.version_extension_installee && statut.version_extension_installee) {  // Chrome utilise un autre dossier que celui mis à jour
    e.textContent = `⚠ Mise à jour reçue (${statut.version_extension_installee}) mais Chrome utilise la ${charge}. Dans chrome://extensions : retire Salopar DL, puis « Charger l'extension non empaquetée » > ${statut.dossier_extension}`;
    e.className = 'ko'; e.title = statut.dossier_extension; return;
  }
  if (r?.dispo) e.textContent = `Salopar DL ${v} · 🆕 ${r.version} disponible`;
  else if (r?.configure === false) { e.textContent = `Salopar DL ${v} · ⚠ mises à jour non configurées (réinstalle avec le zip complet)`; e.className = 'ko'; }
  else if (r?.erreur) { e.textContent = `Salopar DL ${v} · ⚠ ${r.erreur}`; e.className = 'ko'; }
  else e.textContent = `Salopar DL ${v} · ✓ à jour`;
}
let derniereMaj = null;
function bandeauMaj(r) {
  derniereMaj = r; etatMaj(r);
  if (!r?.dispo) { $('#nouveau').hidden = true; return; }
  $('#nouveau').hidden = false;
  $('#nv-titre').textContent = `🆕 Salopar DL ${r.version} disponible`;
  $('#nv-notes').textContent = r.notes || `Tu as la ${r.courante}.`;
  $('#nouveau').classList.toggle('alerte', !!r.obligatoire);
}
chrome.storage.local.get({ maj: null }).then(r => bandeauMaj(r.maj));
envoyer('maj_check').then(bandeauMaj).catch(x => etatMaj({ erreur: x.message }));
$('#verif').addEventListener('click', async e => {
  e.target.disabled = true; $('#v-sdl').textContent = 'Recherche…';
  try { bandeauMaj(await envoyer('maj_check')); } catch (x) { etatMaj({ erreur: x.message }); }
  e.target.disabled = false;
});
$('#nv-btn').addEventListener('click', async e => {
  e.target.disabled = true; e.target.textContent = 'Mise à jour…';
  try { await envoyer('maj_apply'); e.target.textContent = '✓ Redémarrage…'; setTimeout(() => location.reload(), 1500); }
  catch (x) { e.target.textContent = 'Mettre à jour'; e.target.disabled = false; alert(x.message); }
});
chargerStatut();
chargerOnglet();
