/* Salopar DL — service worker : parle au programme installé sur le PC (Native Messaging),
   garde la liste des téléchargements, notifications, clic droit et raccourcis clavier. */
'use strict';

const HOTE = 'com.salopar.dl';
const MAX_HISTO = 60;
let port = null;
let seq = 1;
const attente = new Map();            // id de requête -> {resolve, reject, minuteur}
const jobs = new Map();               // id -> job (téléchargements connus)
const vues = new Set();               // onglets YouTube/TikTok et popup ouverts (pour la progression en direct)
let dernierStatut = null;
let minuteurInactif = null;
const notifies = new Set();

/* ── Historique (gardé même si Chrome redémarre) ── */
const pret = chrome.storage.local.get({ historique: [] }).then(({ historique }) => {
  for (const j of historique) jobs.set(j.id, j);
});
async function sauverHistorique() {
  const liste = [...jobs.values()].sort((a, b) => (b.debut || 0) - (a.debut || 0)).slice(0, MAX_HISTO)
    .map(j => (['attente', 'telechargement', 'conversion'].includes(j.etat) ? j : { ...j, vitesse: null, eta: null }));
  await chrome.storage.local.set({ historique: liste });
}
const actifs = () => [...jobs.values()].filter(j => ['attente', 'telechargement', 'conversion'].includes(j.etat));

/* ── Connexion au programme ── */
const texteAbsent = 'Le programme Salopar DL n’est pas installé sur ce PC (ou a été déplacé). Lance INSTALLER.bat puis recharge la page.';
function connecter() {
  if (port) return port;
  try {
    port = chrome.runtime.connectNative(HOTE);
  } catch (e) {
    dernierStatut = { ok: false, absent: true, erreur: texteAbsent };
    return null;
  }
  port.onMessage.addListener(recevoir);
  port.onDisconnect.addListener(() => {
    const err = chrome.runtime.lastError?.message || '';
    port = null;
    const absent = /not found|forbidden|access to the specified native messaging host|Specified native messaging host/i.test(err);
    const msg = absent ? texteAbsent : 'Le programme s’est arrêté. Réessaie (s’il plante encore, relance INSTALLER.bat).';
    for (const p of attente.values()) { clearTimeout(p.minuteur); p.reject(new Error(msg)); }
    attente.clear();
    if (absent || err) dernierStatut = { ok: false, absent, erreur: msg };
    for (const j of actifs()) majJob({ ...j, etat: 'erreur', erreur: 'Interrompu (le programme s’est arrêté).' });
  });
  return port;
}

function requete(cmd, args = {}, delai = 120000) {
  return new Promise((resolve, reject) => {
    const p = connecter();
    if (!p) return reject(new Error(texteAbsent));
    const id = seq++;
    const minuteur = setTimeout(() => { attente.delete(id); reject(new Error('Le programme ne répond pas.')); }, delai);
    attente.set(id, { resolve, reject, minuteur });
    try { p.postMessage({ id, cmd, ...args }); } catch (e) { clearTimeout(minuteur); attente.delete(id); reject(new Error(texteAbsent)); }
    surveillerInactivite();
  });
}

function recevoir(m) {
  if (m.event === 'job') return majJob(m.job);
  const p = attente.get(m.id);
  if (!p) return;
  attente.delete(m.id); clearTimeout(p.minuteur);
  if (m.ok) p.resolve(m); else p.reject(new Error(m.erreur || 'Erreur inconnue.'));
}

/* La connexion garde le service worker en vie pendant les téléchargements ; on la coupe quand tout est calme. */
function surveillerInactivite() {
  clearTimeout(minuteurInactif);
  minuteurInactif = setTimeout(() => {
    if (!actifs().length && !attente.size && port) { port.disconnect(); port = null; }
    else surveillerInactivite();
  }, 90000);
}

/* ── Téléchargements ── */
function diffuser(msg) {
  for (const v of vues) { try { v.postMessage(msg); } catch { vues.delete(v); } }
}
function majJob(j) {
  const avant = jobs.get(j.id) || {};
  const job = { ...avant, ...j, titre: j.titre || avant.titre, vignette: j.vignette || avant.vignette };
  jobs.set(job.id, job);
  diffuser({ type: 'job', job });
  badge();
  if (['fini', 'erreur', 'annule'].includes(job.etat) && !notifies.has(job.id) && !['fini', 'erreur', 'annule'].includes(avant.etat)) {
    notifies.add(job.id);
    sauverHistorique();
    if (job.liste) {  // playlist : une seule notification à la fin, pas une par vidéo
      if (!actifs().some(j => j.liste === job.liste)) notifierListe(job.liste);
    } else notifier(job);
  }
}
let majDispo = null;
function badge() {
  const n = actifs().length;
  chrome.action.setBadgeText({ text: n ? String(n) : (majDispo ? '↑' : '') });
  chrome.action.setBadgeBackgroundColor({ color: n ? '#ff4fa3' : '#2fbf71' });
}

/* ── Mises à jour de Salopar DL (gérées par le propriétaire) ── */
async function verifierMaj() {
  try {
    const r = await requete('maj_check', {}, 30000);
    majDispo = r.dispo ? r : null;
    await chrome.storage.local.set({ maj: majDispo });
    badge();
    if (r.dispo && r.auto) await appliquerMaj();   // le propriétaire a demandé une mise à jour automatique
    return r;
  } catch (e) { return { dispo: false, erreur: e.message }; }
}
async function appliquerMaj() {
  const r = await requete('maj_apply', {}, 180000);
  await chrome.storage.local.set({ maj: null });
  majDispo = null; badge();
  setTimeout(() => chrome.runtime.reload(), 700);  // recharge l'extension avec les nouveaux fichiers
  return r;
}
chrome.alarms.create('sdl-maj', { delayInMinutes: 1, periodInMinutes: 360 });
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'sdl-maj') verifierMaj(); });
chrome.storage.local.get({ maj: null }).then(r => { majDispo = r.maj; badge(); });
async function notifier(job) {
  const { notifications } = await chrome.storage.sync.get({ notifications: true });
  if (!notifications || job.etat === 'annule') return;
  const ok = job.etat === 'fini';
  chrome.notifications.create('sdl-' + job.id, {
    type: 'basic', iconUrl: 'icons/128.png', priority: 1,
    title: ok ? `✅ ${job.format === 'mp3' ? 'MP3' : 'MP4'} prêt` : '❌ Téléchargement impossible',
    message: (job.titre || job.nom || job.url || '').slice(0, 120) + (ok ? '' : `\n${job.erreur || ''}`),
    buttons: ok ? [{ title: '▶ Ouvrir' }, { title: '📁 Afficher dans le dossier' }] : []
  });
}
async function notifierListe(nom) {
  const { notifications } = await chrome.storage.sync.get({ notifications: true });
  if (!notifications) return;
  const l = [...jobs.values()].filter(j => j.liste === nom);
  const ok = l.filter(j => j.etat === 'fini').length;
  chrome.notifications.create('sdl-liste-' + Date.now(), { type: 'basic', iconUrl: 'icons/128.png', priority: 1, title: `✅ Playlist terminée : ${ok}/${l.length}`, message: nom.slice(0, 120) });
}
chrome.notifications.onClicked.addListener(id => { if (id.startsWith('sdl-')) ouvrir(id.slice(4), false).catch(() => { }); chrome.notifications.clear(id); });
chrome.notifications.onButtonClicked.addListener((id, i) => { if (id.startsWith('sdl-')) ouvrir(id.slice(4), i === 1).catch(() => { }); chrome.notifications.clear(id); });

async function telecharger({ url, format, qualite, titre, vignette, liste }) {
  await pret;
  const r = await requete('download', { url, format, qualite, titre, vignette, liste }, 20000);
  majJob(r.job);
  sauverHistorique();
  return r.job;
}
async function ouvrir(id, dossier) {
  await pret;
  const j = jobs.get(id);
  return requete(dossier ? 'folder' : 'open', { job: id, fichier: j?.fichier || '' }, 15000);
}

/* ── Messages des pages et du popup ── */
chrome.runtime.onConnect.addListener(p => {
  if (p.name !== 'sdl-vue') return;
  vues.add(p);
  pret.then(() => p.postMessage({ type: 'jobs', jobs: [...jobs.values()] }));
  p.onDisconnect.addListener(() => vues.delete(p));
});

chrome.runtime.onMessage.addListener((m, sender, repondre) => {
  (async () => {
    await pret;
    switch (m.type) {
      case 'statut': {
        try { const r = await requete('ping', {}, 6000); dernierStatut = { ok: true, ...r }; }
        catch (e) { dernierStatut = { ok: false, absent: /installé/.test(e.message), erreur: e.message }; }
        return dernierStatut;
      }
      case 'info': return await requete('info', { url: m.url }, 60000);
      case 'telecharger': return { job: await telecharger(m) };
      case 'annuler': await requete('cancel', { job: m.job }, 10000); return {};
      case 'annuler_tout': await requete('cancel_all', {}, 10000); return {};
      case 'playlist': return await requete('playlist', { url: m.url }, 90000);
      case 'telecharger_liste': {  // toute une playlist : un téléchargement par vidéo, rangés dans un dossier à son nom
        const out = [];
        for (const e of (m.entrees || []).slice(0, 150)) out.push(await telecharger({ url: e.url, format: m.format, qualite: m.qualite, titre: e.titre, vignette: e.vignette, liste: m.nom }));
        sauverHistorique();
        return { jobs: out.length };
      }
      case 'ouvrir': await ouvrir(m.job, false); return {};
      case 'dossier': if (m.job) await ouvrir(m.job, true); else await requete('folder', {}, 15000); return {};
      case 'jobs': return { jobs: [...jobs.values()].sort((a, b) => (b.debut || 0) - (a.debut || 0)) };
      case 'effacer': {
        for (const id of m.jobs || []) { if (!['attente', 'telechargement', 'conversion'].includes(jobs.get(id)?.etat)) jobs.delete(id); }
        await sauverHistorique(); diffuser({ type: 'jobs', jobs: [...jobs.values()] }); return {};
      }
      case 'config': return await requete('config', { config: m.config || {} }, 10000);
      case 'choisir_dossier': return await requete('choose_folder', {}, 600000);
      case 'maj': return await requete('update', {}, 600000);
      case 'maj_check': return await verifierMaj();
      case 'maj_apply': return await appliquerMaj();
      default: throw new Error('Message inconnu');
    }
  })().then(r => repondre({ ok: true, ...r }), e => repondre({ ok: false, erreur: e.message }));
  return true;
});

badge();
