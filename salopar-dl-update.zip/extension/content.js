/* Salopar DL — aucun bouton sur les pages. Ce petit script dit seulement au popup quelle vidéo est ouverte (utile sur TikTok, où l'adresse ne change pas dans le fil). */
(() => {
  'use strict';
  if (window.__saloparDL) return;
  window.__saloparDL = true;
  const SITE = location.hostname.includes('tiktok') ? 'tiktok' : 'youtube';
  function urlTikTok(video) {
    const ici = location.pathname.match(/\/video\/(\d+)/);
    let el = video;
    for (let i = 0; i < 14 && el && el !== document.body; i++, el = el.parentElement) {
      if (i > 0 && el.querySelectorAll('video').length > 1) break;
      const lien = el.querySelector?.('a[href*="/video/"]');
      if (lien) return lien.href.split('?')[0];
      const ids = [el.id, ...[...el.querySelectorAll('[id*="xgwrapper"], [data-video-id], [id^="one-column-item"]')].map(x => x.id || x.dataset.videoId)].join(' ');
      const m = ids.match(/(\d{17,21})/);
      if (m) return `https://www.tiktok.com/@/video/${m[1]}`;
    }
    if (ici) return location.origin + location.pathname;
    return null;
  }
  function urlCourante() {
    if (SITE === 'youtube') return /^\/(watch|shorts\/)/.test(location.pathname) ? location.href : null;
    let meilleure = null, aire = 0;
    for (const v of document.querySelectorAll('video')) {
      const r = v.getBoundingClientRect();
      const a = Math.max(0, Math.min(r.bottom, innerHeight) - Math.max(r.top, 0)) * Math.max(0, Math.min(r.right, innerWidth) - Math.max(r.left, 0));
      if (a > aire) { aire = a; meilleure = v; }
    }
    return meilleure ? urlTikTok(meilleure) : (/\/video\/\d+/.test(location.pathname) ? location.href : null);
  }
  chrome.runtime.onMessage.addListener((m, s, repondre) => {
    if (m.type === 'url_courante') { repondre({ url: urlCourante() }); return; }
  });
})();
